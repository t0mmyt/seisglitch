README for deglitchSEIS

Main matlab function for deglitching: deglitchSEIS.m

Matlab script for quick tests: mainTests.m

All other scripts and files are used inside of deglitchSEIS.m

The "data" directory is the suggested directory to put the data and
metadata for deglitching; but it is up to the user.

Contact: baptiste.pinot@isae-supaero.fr
