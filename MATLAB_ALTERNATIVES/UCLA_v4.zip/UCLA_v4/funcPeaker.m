function [datac,aa]=funcPeaker(time,data,I1,cclim,pflag)
%%%%% fits green2sps function to peaks in data                         
%%%%  datac are cleaned 2sps data
%%%% I1 are indexes of peaks found in findmaxs
%%%% cclim is threshold for correlation
%%%% pflag =1 if plots of fits required
aa=[];
fact=1e-11;
fflag=0;
load green2sps green2sps;
green=green2sps;
kkk=0;
n2old=0;
data=reshape(data,1,length(data));
datac=data;
out=[];n2=1;n2old=2;
wplus=40;               %%%%%% range of green after  peak used
wminus=12;              %%%%%% range of green before peak used
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for j=1:length(I1)
%%%%%%%%%%% case 1 one peak %%%%
% n1=I1(j)-wminus;
% n2=I1(j)+wplus-1;
% Amp=data(I1(j));
% ALoc=I1(j:j)-n1;
% gflag=1;
        a=[];Amp=[];Aloc=[];
        n1=j;
        n2=min([j+3,length(I1)]);
        D=diff(I1(n1:n2)); %%%% get next 2 differences
        D=[D,ones(1,4)*1e6];
%%%% case 1  just one glitch         
if D(1) >= wplus 
n1=I1(j)-wminus;
n2=I1(j)+wplus-1;
Amp=data(I1(j));
ALoc=I1(j:j)-n1;
gflag=1;
    end
%%%% case 2  Two glitch     
     if D(1) < wplus 
n1=I1(j)-wminus;
n2=I1(j+1)+wplus;
Amp=data(I1(j:j+1));
ALoc=    I1(j:j+1)-n1;   %%%%%% max lies Aloc after start
gflag=2;     
     end
%%%% case 3 Two adjactent glitches
    if D(1) < wplus && D(2) < wplus 
n1=I1(j)-wminus;
n2=I1(j+2)+wplus-1;
Amp=data(I1(j:j+2));
ALoc=    I1(j:j+2)-n1;
gflag=3;
    end
%%%% case 4 Three adjactent glitches    
    if D(1) < wplus && D(2) < wplus && D(3) < wplus
n1=I1(j)-wminus;
n2=I1(j+3)+wplus-1;
Amp=data(I1(j:j+3));
ALoc=    I1(j:j+3)-n1;
gflag=4;
    end
 

if n1 > n2old   %%%%% nake sure new glitch
if n2 > length(data), n2=length(data);end
%%
y=data(n1:n2);
Amp=Amp-y(1);   
%%%%%%%%%%%%%%%%%%%% find starting values %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
x=1:length(y); %%%% half width where green peaks
a=[Amp,ALoc];
slope=(y(end)-y(1))/(x(end)-x(1));
line=y(1)+slope*(x-x(1));
f=greenfitSlope(a,x,green,y,gflag,wminus);
fact=1;mylsq; %%%% gentle start hig damping
fact=1e-11;   %%%% low damping
j
for i=1:5,mylsq;end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    cc=corrcoef(f,y);ccc=cc(1,2);

%%%%%%%%%%%%%%%%%%%%% Is cc high enough %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   if abs(ccc)>cclim
   datac(n1:n2)=y-f+line;
   for ij=1:gflag
   kkk=kkk+1;
   M=length(y);
   jj=j+ij-1;
   aa(kkk,1:length(a)+5)=[ccc,I1(jj),time(I1(jj)),M,gflag,a];
   end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 
 if pflag>0
 figure(1)
 clf
 hold on
 plot(x,y,'r*',x,f)
 title([' XC = ', num2str(ccc),' I1=  ',num2str(I1(j))])
 pause(0.1);
end  %%%% plot
end  %%%% cc ok
%%
n2old=I1(j+gflag-1);  %%% location of last peak in sequence
end%%%%% go to new glitch sequence 
end  %%%%% j loop
%%

if pflag>0
figure(301);clf
I11=aa(:,2);
plot(time',datac+5*std(datac))
hold on

plot(time',data-5*std(datac),'k')

plot(time(I11),data(I11)-5*std(datac),'r*')

figure(301)
xlabel([datestr(datevec(time(1))),' to  ', datestr(datevec(time(end)))], ...
'fontsize',16)
 xlim = [min(time),max(time)];
datetick('x','keeplimits')

 title(['No. Peaks Removed = ',num2str(kkk)])
 %ylim([-10e4,8e4])
 figure(301)
end
 

