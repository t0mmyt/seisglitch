%%%%% prepare starting values for N glitch  + N spike fit
%%%%% greent truncated to fit y spiket same truncation

%%%%% Spike location
%%%%  preparation for f = NSpikeGreenLine(a,x,y,green,spike,N)
%%%%  fflag=6
%%%%  a(1,5,9,13)=amplitude green
%%%%  a(2,6,10,14)=phase green and spike
%%%%  a(3,7,11,15)=amp spike
%%%%  a(16)=linear slope
%%%%  a(17)=quadratic term
%%%%  a(18)=amplitude spike
%a=zeros(1,4*gflag+3);
x=1:length(y);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Load Green %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    load green20sps.mat;
    green20sps=[green20sps,zeros(1,1000)];
    [my,ixy]=max(green20sps);
    greent=green20sps(ixy-119:ixy-119+length(y)-1);
    greent=greent/max(greent);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Load Spike %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    load greenspike.mat;
    spike=greenspike/max(greenspike);
    spike=[spike,zeros(1,1000)];
    spiket=spike(ixy-119:ixy-119+length(y)-1)/max(spike);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
        

j=0;
for i=1:gflag
    j=j+1;
    ix1=(i-1)*4+1;  %%% 1 5 9  13  amp green
    ix2=ix1+1;      %%% 2 6 10 14  phs green
    ix3=ix2+1;      %%% 3 7 11 15  amp spike
    ix4=ix3+1;      %%% 4 8 12 16  phs spike
    a(ix1)=AMP(j);                  %%%%% amp green
    a(ix2)=PHASE(j);                %%%%% phase green
    a(ix3)=1e-2;                    %%%%% amp spike
    a(ix4)=1e-2;                    %%%%% phase spike  
end
%%%%% line added
a(ix4+1)=mean(y(1:10));
a(ix4+2)=1e-6;
a(ix4+3)=1e-6;


fflag=8;
N=gflag;
 green=greent;
 spike=spiket;
%%%%% fit without spikes 
func
a=a+1e-7; %%%%% avoid zeros
fact=1;
mylsq;
j=0;
for i=1:gflag
    j=j+1;
    ix1=(i-1)*4+1;  %%% 1 5 9  13  amp green
    ix2=ix1+1;      %%% 2 6 10 14  phs green
    ix3=ix2+1;      %%% 3 7 11 15  amp spike
    ix4=ix3+1;      %%% 4 8 12 16  phs spike

mn1=round(PHASE(j)-80); 
mn2=round(PHASE(j)-22);
if gflag==1;mn1=1;mn2=120;end
if j>1 
    mn1=round(PHASE(j-1));
    mn2=round(PHASE(j  ));
end
%%%%% test for out of limit cases    
if mn1<1;mn1=1;end
if mn2<1;mn2=120;end
if mn2>length(y);mn2=length(y);end

if gflag==1;mn1=50;mn2=120;end
%%%% search all the way to the peak
range=mn1:mn2;
D=(y-f);
D=D(range);D=detrend(D);
 [B,A]=butter(2,[.1],'high');
 D=filtfilt(B,A,D);


[spikett,p1,p2,ccs]=TruncateXcov(spiket,D);
[amp,DT]=SampleFraction(spikett,D);

[ms,is]=max(spiket);
    a(ix3)=amp+1e-7;           %%%%% amp spike1
    a(ix4)=is+mn1-p1+DT+1e-7;  %%%%% phase spike1  
    
end
func

% plot(x,y,x,f,x,y-f+y(1)+2000);
% figure(1)
% fact=10;







