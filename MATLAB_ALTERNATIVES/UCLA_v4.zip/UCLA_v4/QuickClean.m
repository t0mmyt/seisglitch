%%%%%% quick clean of data to get lta
I2=find(sta>3*std(sta));  %%%%% large values of short term average sta
I1=[];
kk=0;start=I2(1);
for i=1:length(I2)-1
    if I2(i+1)-I2(i)>1;
        rend=I2(i);
        range=[start:1:rend];
        start=I2(i+1);
        kk=kk+1;I1(kk)=round(mean(range));
    end
end
data=dataf;
%%%%%% makes a crude datac
pflag=0;
datacf=funcPeaker(time,dataf,I1,0.6,pflag);