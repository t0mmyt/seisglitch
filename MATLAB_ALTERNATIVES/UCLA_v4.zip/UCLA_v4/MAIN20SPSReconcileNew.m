%%%%%%%%%% Finds missed correlated sianals on other channnels %%%%%%
k=0;
I1P=I0P; 
I11P=cell(3,1);
kk=0;
idx=[];
outcc=[];

close all
clear out
%%%%%%% do for every found glitch so far
for jk=1:3
    ii=1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

while ii<=length(I1P{jk})

     gflag=G1P{jk}(ii);
     ii0=ii; 
     N1=I1P{jk}(ii)*-12;
     if      N1<1,N1=1; end
     N2=N1+50;
     ii=ii+1; 
     
     if N2>length(data2{jk}),N2=length(data2{jk});end
     y1=detrend(filtfilt(B,A,data2{1}(N1:N2)))';x=1:length(y);
     y2=detrend(filtfilt(B,A,data2{2}(N1:N2)))';x=1:length(y);
     y3=detrend(filtfilt(B,A,data2{3}(N1:N2)))';x=1:length(y);
     c1=corrcoef(y2,y3); outcc(ii0,1)=c1(1,2);
     c2=corrcoef(y1,y3); outcc(ii0,2)=c2(1,2);
     c3=corrcoef(y1,y2); outcc(ii0,3)=c3(1,2);
     %%%%%%%%%%%% store indexes
     idx(ii0)=I1P{jk}(ii0);
     %%%%%% do we have correlated pairs
     
     
     x=1:length(y1);
    
%      subplot(3,1,1)
%      plot(x,y1,x,y2);
%      title(num2str(outcc(ii0,1),3))
%      subplot(3,1,2)
%      plot(x,y2,x,y3);
%      title(num2str(outcc(ii0,2),3))
%      subplot(3,1,3)
%      plot(x,y1,x,y3);
%      title(num2str(outcc(ii0,3),3))
%      
%      pause
end

%%
%%%%%%%%%%%%% find correlated indexes %%%%%%%%%%%%%%%%%%%%                   cc2   cc3
if jk==1; test1=2;test2=3;ix1=3;ix2=2; end %%%% test index 1 against 2 and 3 {1,3} {1,2}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                   cc3   cc1
if jk==2; test1=3;test2=1;ix1=1;ix2=3;end %%%% test index 2 against 1 and 3 {1,2} {2,3}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                   cc1   cc2
if jk==3; test1=1;test2=2;ix1=2;ix2=1;end %%%% test index 3 against 1 and 2 {2,3} {1,3} 


[M,N]=size(outcc);
for j=1:M
    %%%%%%% test 1 and 2
    if abs(outcc(j,test1))>0.8 
        [mx,ix] = min(abs(I1P{ix1}-idx(j)));
        %%%% is it a new event
        %return
        if abs(mx)>5
                    k=k+1;
                    I11P{ix1}=[I11P{ix1},idx(j)];
        end
    end
    
        %%%%%%% test 2 and 3

    if abs(outcc(j,test2))>0.8
        [mx,ix] = min(abs(I1P{ix2}-idx(j)));
         %%%% is it a new event
        if abs(mx)>5
                    kk=kk+1;
                    I11P{ix2}=[I11P{ix2},idx(j)];
        end
    end

    
    
end

end
for jk=1:3
 I1P{jk} = [I1P{jk}',unique(I11P{jk})]';
 G1P{jk} = [G1P{jk}',unique(I11P{jk})./unique(I11P{jk})]';
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
