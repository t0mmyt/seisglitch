%%%% adjust start and end times to be the same for 3 channels after
%%%% XseedFDS
function [timesA,dataA]=funcAdjustTimes(times,data)
t1=times{1};
t2=times{2};
t3=times{3};


d1=data{1};
d2=data{2};
d3=data{3};


[tstart,ix]=max([t1(1),t2(1),t3(1)]);
[tend,ix]=min([t1(end),t2(end),t3(end)]);
%%% round off error
tend=tend+0.01/24/3600;
tstart=tstart-0.01/24/3600;

I1=find(t1>=tstart & t1<=tend);tt1=t1(I1);
I2=find(t2>=tstart & t2<=tend);tt2=t2(I2);
I3=find(t3>=tstart & t3<=tend);tt3=t3(I3);


dd1=d1(I1);
dd2=d2(I2);
dd3=d3(I3);

dataA=cell(1,3);
timesA=cell(1,3);
dataA{1}=dd1;
dataA{2}=dd2;
dataA{3}=dd3;

timesA{1}=tt1;
timesA{2}=tt2;
timesA{3}=tt3;


