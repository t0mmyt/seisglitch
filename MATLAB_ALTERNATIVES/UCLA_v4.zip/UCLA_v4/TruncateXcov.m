%%%%%%% cut long series to maximize xcc with short
function [longt,p1,p2,cc]=TruncateXcov(long,short)
L=length(long);
[ml,ixl]=max(long);
out=xcov(short,long); %%%%%% xcorr demeaned
[mg,ixcv]=max(abs(out));
is=ixcv-L+ixl;
p1=ixl-is+1;
if p1<=0, p1=1; end
p2=p1+length(short)-1;
if p2>L,  p2=L; end
longt=long(p1:p2);
mult=short/longt;
cc1=corrcoef(longt,short);
cc=cc1(1,2);



