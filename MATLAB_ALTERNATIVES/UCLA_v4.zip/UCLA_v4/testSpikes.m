%%%%%% are the found spikes significantly above background noise.  This is
%%%%%% run after the spies and he glitches have been fit by lsq
function a=testSpikes(a,x,y,f,greent,spiket,fflag,gflag,NLIM)
eps=1e-7;
if fflag==3 %%%%% spike a(6),a(7), phase Green = a(2)
    asave=a(6);
    a(6)=eps;
    func
    D=y-f;
    N=round(a(2));
    if N > length(y); N=round(mod(a(2),length(y)));end  %%%%% wraparounds
    S=round(a(7));
    if S<1, return,end
    Dt=[D(1:S-10),D(S+10:N)];
    if abs(D(S))>NLIM*std(Dt)
        a(6)=asave;
    end
end
    
if fflag==39 %%%%% spike a(8),a(9), phase Green = a(2)
    asave=a(8);
    a(8)=eps;
    func %%%%%%% do func without spike
    D=y-f;
    N=round(a(2));
    if N > length(y); N=round(mod(a(2),length(y)));end  %%%%% wraparounds

    S=round(a(9));
    if S<1, return, end
    if S>length(D)-10, return, end

    Dt=[D(1:S-10),D(S+10:N)];
    if abs(D(S))>NLIM*std(Dt)
    a(8)=asave;
    end
end
   
if fflag==8 %%%%% spike a(8),a(9), phase Green = a(2)
    j=1;
    for i=1:gflag
    j=j+1;
    ix1=(i-1)*4+1;  %%% 1 5 9  13  amp green
    ix2=ix1+1;      %%% 2 6 10 14  phs green
    ix3=ix2+1;      %%% 3 7 11 15  amp spike
    ix4=ix3+1;      %%% 4 8 12 16  phs spike
    asave=a(ix3);
    a(ix3)=eps;
    func
    N=round(a(ix2));                %%%%% phase green
    if N > length(y); N=round(mod(a(2),length(y)));end  %%%%% wraparounds

    S=round(a(ix4));                %%%%% phase spike
    if S<1, break,end
    if S>length(y)-10, break,end

    D=y-f;
    Dt=[D(1:S-10),D(S+10:N)];
        if abs(D(S))>NLIM*std(Dt)
            a(ix3)=asave;
        end
    end
    
end
    
    

