% changes phase of a series
function y=rephase(f,dt,DT)
% y=rephase(f,dt,DT)
% f is the data series even number of points, dt is digitization interval, DT is the phase lag + delay.
nn=length(f);
%%%% add a zero if odd number.
mm=ceil(nn/2)*2;if mm> nn f=[f,0];end
T=nn*dt;
ii=sqrt(-1);
wu=[0:mm/2]*2*pi/T;wd=-[mm/2-1:-1:1]*2*pi/T;w=[wu,wd];
			%phase change
fb=fft(f);fbp=fb.*exp(-ii*w*DT);

fp=ifft(fbp);y=real(fp);
%%%% get rid of extra point
if mm> nn, y=y(1:nn);end


