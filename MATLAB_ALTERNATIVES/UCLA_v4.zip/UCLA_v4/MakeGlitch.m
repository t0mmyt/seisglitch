function [green20sps,spike20sps,green2sps]=MakeGlitch(ch)
 DIRNAME = '~/Box Sync/INSIGHT/GLITCH_LIB/';
[gain, z2, p , ~, A0]=read_resp_v2(strcat(DIRNAME,'metadata/RESP.XB.ELYSE.02.BH',ch));
dt=0.01;     % Sampling time
NS=102400;	 % Length of the Green function in points

PFO5=load('PFO_div5.txt');
PFO2=load('PFO_div2.txt');

%%%%% built Green response from Pole and Zero (remove the two first null zero)
green100sps(1:NS)=0.;
green100sps(NS/2)=1.;	% impulse function
%time100sps=(0:NS-1)*dt;
tf100sps=fft(green100sps);
tf1100sps=tf100sps;
NF=floor(NS/2+1);
omega100sps(1:NF)=(0:NF-1)/(NS*dt)*(2*1i*pi);

%%%% remove the two first zero and keep the other ones
for zero=3:length(z2)
	tf100sps(1:NF)=tf100sps(1:NF).*(omega100sps(1:NF)-z2(zero));
end
%%%% take all poles
for pole=1:length(p)
    %ff=1; if pole<=1;ff=.1;'boo',end
	tf100sps(1:NF)=tf100sps(1:NF)./(omega100sps(1:NF)-p(pole));
end
%tf100sps(:) = kTransfer(2)*tf100sps(:);
sensitivity=8.626220E+10*80;
tf100sps(:) = sensitivity*tf100sps(:);
%%%%% multiply  by omega squared to get displacement response %%%%%%%%%%%%%
tf1100sps(1:NF)=tf100sps(1:NF).*omega100sps(1:NF).*omega100sps(1:NF); 

%%%%% get the time function of the Green response to step acceleration
green100sps=ifft(tf100sps,'symmetric');
green100sps_1=ifft(tf1100sps,'symmetric');%This is response to displacement
%%%%%%%%%%%%%%%%%%%%%%%%%%%%i omega squared %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
xx=1:length(green100sps);
gain5=sum(PFO5);
gain2=sum(PFO2);
%%%%%% decimate by 5
green20sps   =decimeFPGA(green100sps,  5,PFO5,gain5);  %%%  velocity out glitch due to an acceleration step  iw^2 was removed 
green20sps_1d=decimeFPGA(green100sps_1,5,PFO5,gain5);  %%%  velocity out glitch due to a  displacement step  mult iw^2 replaced
green4sps=decimeFPGA(green20sps,5,PFO5,gain5);
green2sps=decimeFPGA(green4sps,2,PFO2,gain2);
spike20sps=green20sps_1d;
xx=1:length(green20sps);
plot(xx,green20sps,xx,spike20sps);
figure(1)
pause(1)

