%%%%% for use after MAIN2SPS
figure(jk+100)
clf
Is=I1P{jk}(I1P{jk}>0);
NT=length(time)
dataorig=dataorigout(jk,1:NT);
datac=datacout(jk,1:NT);
off=5*std(detrend(datac));
%dataf=datafout(jk,1:NT);
hold on
%%%%% plot original data and locations of all maxima
plot(time,dataorig,'k',time(Is),dataorig(Is),'r*')
plot(time,datac+off,'b')  %%% first clean
% plot(time,datacout(2,:)+2*off,'k',time(I1c),datacout(2,I1c)+2*off,'r*') %%% second clean
% plot(time,datacout(3,:)+3*off,'r')  %%% third clean

 xlim = [min(time),max(time)];
 
%%%%%%%%%%%%%%%%%% set up axes %%%%%%%%%%%%%%%%%%%%%%
set(gca,'XLim',xlim)
datetick('x','keeplimits')
xlabel([datestr(datevec(time(1))),' to  ', datestr(datevec(time(end)))], ...
'fontsize',16)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

