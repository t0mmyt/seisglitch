% finds maximum values in data  above a threshold level
I1=[];I2=[];loc=[];peak=[];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Nlevel number standard dev s/m %%%%%%%%%%%%%
%level=Nlevel*std(dataratio);
level=Nlevel;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
kk=0;
absdata=abs(dataratio);
%%
for i=3:length(dataratio)-2
    if absdata(i)>absdata(i-1)  && absdata(i)>absdata(i+1) ...  
    && absdata(i)>absdata(i-2)  && absdata(i)>absdata(i+2)         %%%% find peak
        kk=kk+1;                                                   %%%% peak index
        peak(kk)=dataratio(i);                                     %%%% peak amplitude
        loc(kk)=i;                                                 %%%% location
    end
end
%%
% find peaks above the noise level
I2=find(peak>level);                
%%%%% sort them 
%%
num =loc(I2);                                  %%%% index of large peaks
amp=peak(I2);                                  %%%% amp   of large peaks
cca=[];
%%%%% set up variation near peakmaximum in green function 
[mg,ig]=max(yg);      %%%% max green function
ytest=yg(ig-3:ig+3);  %%%% 7 points about maximum 
ytest=ytest-ytest(1);
ytest=ytest/max(ytest);
%%% find offset that maximizes power in peaks(filtering changed phases)
Inum=find(num<length(dataf)-7 & num >8);
num2=num(Inum);
for i=1:length(num2)
    clf
     for j=1:7
         off=j-4;
         yold=yg;
         n1=num2(i)-3+off;
         n2=num2(i)+3+off;
    y=data(n1:n2);
    y=y-y(1);
    [mx,~]=max(abs(y));
    y=y/mx;
    cc=corrcoef(y,ytest);
    cca(i,j)=cc(1,2);
      end
end
[mx,ix]=max(abs(cca'));
%%
offa=-3:3; %%% offsets when correlation was made 
I1keep=find(mx>0.7);  %% Keep correlated cases 
%%%%%%%%%%%%%%% add offset that maximizes correlation  %%%%%%%%%%%%%%%%%%%%
I1=num2+round(median(offa(ix(I1keep))));

%%   
 figure(1001)
 subplot(2,1,1)
 plot((1:length(data)),data,I1,data(I1),'r*')
  title('peaks of data')

 subplot(2,1,2)
 plot((1:length(data)),dataratio,num2,dataratio(num2),'b*',[1,length(data)],[level,level])
 title('peaks of data ratio above threshold')

 
 