function [I1P,G1P,a1P]=findI1PG1P(aaout)
    I1P=cell(3,1);    
    G1P=cell(3,1); 
    a1P=cell(3,1);
 
for jk=1:L
    
        I1P{jk}=squeeze(aaout(jk,:,2))';
        G1P{jk}=squeeze(aaout(jk,:,5))';
        a1P{jk}=squeeze(aaout(jk,:,6:N));

end
% 
% for jk=1:L
%     [I1P{jk},is]=sort(I1P{jk});
%     G1P{jk}=G1P{jk}(is);
%     a1P{jk}=a1P{jk}(is,:);
%     G1P{jk}=G1P{jk}(I1P{jk}>0);
%     a1P{jk}=a1P{jk}(I1P{jk}>0,:);
%     I1P{jk}=I1P{jk}(I1P{jk}>0);
% 
% end
% %end