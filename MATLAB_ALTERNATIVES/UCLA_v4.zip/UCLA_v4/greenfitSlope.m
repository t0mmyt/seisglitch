%%%%%% Get green from Philippes's program and fit to multiple glitches
%%%%%% 
function f=greenfitSlope(a,x,green,y,gflag,wminus)
x=[1:length(x)];
% load green;
% %             [B,A]=butter(2,[0.1],'low');
% %             green=filtfilt(B,A,green);
% load y;
% load gflag;
% load wminus;
dt=1;
N=wminus;%round((length(y)-1)/2);  %%%%% location first peak
green=green/max(green);
%[my,ixy]=max(y);
[mg,ixg]=max(green);
m1=ixg-N;m2=m1+length(y)-1;
f1=green(m1:m2);
slope=(y(end)-y(1))/(x(end)-x(1));
line=y(1)+slope*(x-x(1));
if gflag==1
f=a(1)*rephase(f1,dt,a(2)-N)+line;
elseif gflag==2
f=a(1)*rephase(f1,dt,a(3)-N)+a(2)*rephase(f1,dt,a(4)-N)+line;
elseif gflag==3
f=a(1)*rephase(f1,dt,a(4)-N)+a(2)*rephase(f1,dt,a(5)-N)+a(3)*rephase(f1,dt,a(6)-N)+line;
elseif gflag==4
f=a(1)*rephase(f1,dt,a(5)-N)+a(2)*rephase(f1,dt,a(6)-N)+a(3)*rephase(f1,dt,a(7)-N)+a(4)*rephase(f1,dt,a(8)-N)+line;
end
%   plot(x,f,x,y,'r*')
%   figure(1)
