%%%%% prepare starting values for 2 glitch  + spike fit
%%%%% greent truncated to fit y spiket same truncation
%%%% a(1)=amplitude green
%%%% a(2)=phase green
%%%% a(3)=offset
%%%% a(4)=linear slope
%%%% a(5)=quadratic term
%%%% a(6)=amplitude spike
%%%% a(7)=phase spike
%%%% a(8)=Gaussian sd
%%%% a(9)=amplitude second green
%%%% a(10)=phase second green
a=[];
fflag=3;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Load Green %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load green20sps.mat;
green20sps=[green20sps,zeros(1,1000)];
[my,ixy]=max(green20sps);
greent=green20sps(ixy-119:ixy-119+length(y)-1);
greent=greent/max(greent);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Load Spike %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    load greenspike.mat;
    spike=greenspike/max(greenspike);
    spike=[spike,zeros(1,1000)];
    spiket=spike(ixy-119:ixy-119+length(y)-1)/max(spike);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

a(1)=AMP(1)/50;
a(2)=PHASE(1);                                  %%%% phase green
a(3)=mean(y(1:5));                              %%%% offset
a(4)=(y(end)-y(1))/length(y)*10+1e-7;           %%%% slope
a(5)=1e-7;                                      %%%% x^2
a(6)=1e-7;                                       %%%% spike amp
a(7)=1e-7;                                       %%%% spike phase
a(8)=30;                                        %%%% Gaussian convolver
%%
%%%%% Spike location
func

j=1;

mn1=round(PHASE(j)-80); 
mn2=round(PHASE(j)-22);

if mn1<1;mn1=1;end
if mn2<1;mn2=120;end
if mn2>length(y);mn2=length(y);end
%%%% go all the way to the peak
range=mn1:mn2;

D=(y-f);
D=D(range);D=detrend(D);
[spikett,p1,p2,ccs]=TruncateXcov(spiket,D);
[amp,DT]=SampleFraction(spikett,D);
[ms,is]=max(spiket);
    a(6)=amp+1e-7;           %%%%% amp spike1
    a(7)=is+mn1-p1+DT+1e-7;  %%%%% phase spike1  
func
plot(x,y,x,f);
hold on;
plot(x,y-f+y(1)+500)
fact=10;                               %%% conservative damping factor







