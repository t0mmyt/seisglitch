%%%% Cleans glitches from InSight VBB data
%%%% run XseedDatFDS.m first where the input file is downloaded from FDS
close all
I1P=cell(3,1);
G1P=cell(3,1);
load fetch;
if fetch==1
XseedDataFDS
Data=cell(1,3);
times=cell(1,3);
Data{1}=d2;
Data{2}=d3;
Data{3}=d4;

times{1}=t2;
times{2}=t3;
times{3}=t4;
freq = X(1).SampleRate;
end

load cclim    %%%%%%%%%%%% Threshold model (multiple) glitch to data cc
load Nlevel;       %%%%%%%%%%%% threshold Noise number standard devs of sta/lta


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%% 2 SPS DATA %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
dataout=[];
aaout=[];
dataorigout =[];  %%%% original data
datacout =[];
%%%% if times are not synchronised 
[times,Data]=funcadjustTimes(times,Data);
%freq=fs{1};%%%% convert to 20 sps data
if freq==10,[data20,times20]=ConvertTo20sps(Data,times);end 
data2 =cell(1,3);
times2=cell(1,3);
aaout=[];
fflag=0;    %%%% chooses function fits green and line
fact=1e-11; %%%% damping factor lsq

%%%%%% decimate 20 sps data to 2 sps data to find glitches without
%%%%%% precursors
for jjk=1:3
    data2{jjk}=decimate(Data{jjk},10);
    times2{jjk}=times{jjk}(1:10:end)';
end

close all
%%
aaout=[];
aa=[];
for jk =1:3  %%% 3 components %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    time=times2{jk};
    datac   =data2{jk}';
    dataorig=data2{jk}';
    data    =data2{jk}'; 
    
[B,A]=butter(2,[0.001 0.4]);
stalta;  %%%% finds I1 locations of glitches
pflag=1; %%%% If 1 plots individual fits of func to glitchs data
[datac,aa]=funcPeaker(time,data2{jk},I1,cclim,pflag);
[m,n]=size(aa);
aaout(jk,1:m,1:n)=aa;  %%%%% this is the most useful output data for 
                       %%%%% matching other glitches etc.

I1P{jk}=squeeze(aaout(jk,:,2))';
G1P{jk}=squeeze(aaout(jk,:,5))';
end
%%%%% get rid of zeros
for jk=1:3 
    I1P{jk}=I1P{jk}(I1P{jk}>0);
    G1P{jk}=G1P{jk}(G1P{jk}>0);
end
I0P=I1P; %%%%% save for comparison 
%%
%%%% Add other channels that correlate %%%%%
MAIN20SPSReconcile;                    %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% run again with new channels
I2P=I1P;
aaout=[];
cclim=0.4; %%%%%%%%%%%% new channels lower cc
for jk=1:3
    I1=sort(I1P{jk});
    [datac,aa]=funcPeaker(time,data2{jk}',I1,cclim,pflag);
    [m,n]=size(aa);
    aaout(jk,1:m,1:n)=aa; 
    dataorigout(jk,1:length(data))=dataorig;  %%%% original data
    datacout(jk,1:length(data))=datac;        %%%% after cleaning
end
I1P=[];
G1P=[];
for jk=1:3   
I1P{jk}=squeeze(aaout(jk,:,2))';
G1P{jk}=squeeze(aaout(jk,:,5))';
end
%%%%% get rid of zeros %%%%%%%%
for jk=1:3 
    I1P{jk}=I1P{jk}(I1P{jk}>0);
    G1P{jk}=G1P{jk}(G1P{jk}>0);
end
%%%%%%%%%%%% END %%%%%%%%%%%%%
close all
PlotFinalNew2SPS


 
