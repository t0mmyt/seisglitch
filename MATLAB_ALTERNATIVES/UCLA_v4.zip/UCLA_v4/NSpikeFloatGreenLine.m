function f=NSpikeFloatGreenLine(a,x,y,greent,spiket,gflag)
%%%%%% fits N green function and N spikes 20 sps data
dt=1;
fs=0;
[mg,ig]=max(greent);
[ms,is]=max(spiket);

for i=1:gflag
    ix1=(i-1)*4+1;  %%% 1 5 9 13
    ix2=ix1+1;      %%% 2 6 10 14
    ix3=ix2+1;      %%% 3 7 11 15
    ix4=ix3+1;      %%% 4 8 12 16
fs =fs+a(ix1)*rephase(greent,dt,a(ix2)-ig)+a(ix3)*rephase(spiket,dt,a(ix4)-is);
end
line=a(ix4+1)+a(ix4+2)*(x/10)+a(ix4+3)*(x/10).^2;%  Curved line added

f=line+fs;
% plot(x,y,x,f)
% figure(1)
