%%%% Runs all programs to deglitch 20sps mseed BHU V W data from INSIGHT 
%%%% The data are read into the structured arrays DATA{} and times{}.  The
%%%% final cleaned data are in the structure array dc{}.  The standalone
%%%% programs MAIN2SPS (finds glitches from 2sps data)and MAIN20SPSJuly26
%%%% uses those locations to deglitch and despike 20sps data.
%%%% For help: email pdavisucla@gmail.com %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Note several codes from P Lognonne, B Pinot, B. Kenda, P Davis

 clear
 close all

%%%%                          parameters                               %%%%
%%%% cclim          cross-correlation threshold to accept glitch in 2sps data 
%%%% Nlevel         signal to nois threshold to accept glitches
%%%% Conservative   If = 1  final fit involves only standard glitches and 
%%%%                spikes.  Otherwise tests gaussian convolver and double 
%%%%                glitch with second with exponential  
%%%% NLIMspike      Relative size of spike to keep wrt std surroundings


%%%%% insert file here %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%file = '~/Box Sync/INSIGHT/phase_picking_wg/S0183a/S0183a_VBB.mseed'
%file = '~/Box Sync/INSIGHT/phase_picking_wg/S0173a/S0173a_VBB.mseed'
file = 'S0235b_VBB.mseed'
%%%%%%%%%%%%%%%%%%%%%% Make glich green functions and 20sps spike %%%%%%%%%
[green20sps,greenspike,green2sps]=MakeGlitch('U'); %Uses transfer functions 
%  for glitches, U suffices V W ones very similar
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
save green20sps green20sps;
save greenspike greenspike;
save green2sps  green2sps;


fetch = 1;       %%%%%%%%%%%  Read in data file (1)
cclim = 0.9;     %%%%%%%%%%%  Threshold model (multiple) cc(glitch, data)
cclim2= 0.8;     %%%%%%%%%%%  Threshold check other channels cc(glitch, data)
Nlevel= 4.0;     %%%%%%%%%%%% Threshold number standard devs of sta/lta
Conservative = 0 %%%%%%%%%%%  Standard glitches only (1) or add tests of 
%                %%%%%%%%%%%  Gaussians and exponential (0)
NLIMspike=3      %%%%%%%%%%%  Keep spikes > NLIMspike*std(surroundings)

save fetch  fetch  %%%% used in MAIN2SPS.m to read mseed file
save cclim  cclim  %%%% used in MAIN2SPS.m and findpeaker.m
save cclim2 cclim2 %%%% used in MAIN20SPSReconcile.m
save Nlevel Nlevel %%% used in MAIN2SPS.m and findmaxs.m
save Conservative Conservative % used in MAIN20SPSuly26.m
save NLIMspike NLIMspike %%%%%%  used in MAIN20SPSuly26.m  

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Begin Calculations %%%%%%%%%%%%%%%%%%%%%%%

MAIN2SPS                                %%%% decimates to 2 sps and finds
                                        %%%% glitch locations
pause(3)
%%
MAIN20SPSJuly26                         %%%% removes spikes and glitches in 
                                        %%%% 20sps data output dc{} 
                                        
