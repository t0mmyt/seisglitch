%%%%%%% find fraction of a cycle for precursor
function [amp,DTf]=SampleFraction(spiket,D)
%spiket=spikett
%%%% D is y-f
%%%% ix is max D
%%%% delta is spike aligned on max abs(D)
%%%% is is max of greenspike
% [ms,is]=max(spiket);
ccout=zeros(1,25);
DT =zeros(1,25);

out=xcorr(D,spiket);
[~,ixc]=max(abs(out));
DEL=ixc-length(D);
[~,ix]=max(abs(D));

stest=rephase(spiket,1,DEL);
for i=1:25
    dt=(i-13)*0.1;
    DT(i)=dt;
cc=corrcoef(rephase(stest,1,dt),D);
ccout(i)=cc(1,2);
end
 [~,ic]=max(abs(ccout));
dtout=DT(ic);
amp=(D(ix));
DTf=DEL+dtout;
if isempty(amp)==1,amp=0;end
if isempty(DTf)==1,DTf=0;end

