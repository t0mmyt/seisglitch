a=[];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Load Green %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    load green20sps.mat;
    green20sps=[green20sps,zeros(1,1000)];
    [my,ixy]=max(green20sps);
    greent=green20sps(ixy-119:ixy-119+length(y)-1);
    greent=greent/max(greent);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Load Spike %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    load greenspike.mat;
    spike=greenspike/max(greenspike);
    spike=[spike,zeros(1,1000)];
    spiket=spike(ixy-119:ixy-119+length(y)-1)/max(spike);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Load Green %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

a(1)=AMP(1);                                                %%%% amp green1
a(2)=AMP(1)/2;                                              %%%% amp green2 
a(3)=PHASE(1);                                              %%%% phase green1
a(4)=PHASE(1)+50;                                           %%%% phase green2
a(5)=40;                                                    %%%% exponential decay
a(6)=y(1);                                             
a(7)=1e-7;
a(8)=1e-7;                                                 %%%% Amp spike = 0
a(9)=1e-7;                                                 %%%% Location spike
fflag=39;
%%%% case where spike set to zero %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
func

j=1;
mn1=round(PHASE(j)-80); 
mn2=round(PHASE(j)-22);

if mn1<1;mn1=1;end
if mn2<1;mn2=120;end
if mn2>length(y);mn2=length(y);end

%%%% search all the way to the peak

range=mn1:mn2;
D=(y-f);
D=D(range);D=detrend(D);
[spikett,p1,p2,ccs]=TruncateXcov(spiket,D);
[amp,DT]=SampleFraction(spikett,D);
[ms,is]=max(spiket);
%%%% case where spike included %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    a(8)=amp+1e-7;           %%%%% amp spike1
    a(9)=is+mn1-p1+DT+1e-7;  %%%%% phase spike1  
func
 plot(x,y,x,f);
 hold on;
 plot(x,y-f+y(1)+500)
 fact=10;
% mylsq %%% conservative damping factor
