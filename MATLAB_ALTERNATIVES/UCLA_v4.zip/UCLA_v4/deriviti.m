%PROGRAM deriviti
% sets up derivitive matrix for lsq inversion
mmm=length(a);nnn=length(y);
dela=a/100000;
for jjjj=1:mmm,
a(jjjj)=a(jjjj)+dela(jjjj);
newa=a(jjjj);
func;ff2=f;
a(jjjj)=a(jjjj)-2*dela(jjjj);
func;ff1=f;
a(jjjj)=a(jjjj)+dela(jjjj);
am(1:nnn,jjjj)=[(ff2 - ff1)/(2*dela(jjjj))]';
end

