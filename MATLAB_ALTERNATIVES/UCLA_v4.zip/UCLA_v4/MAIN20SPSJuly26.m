%%%%%%%%%% June 2020 cleans Sol 20SPS Events
cnames=['BHU';'BHV';'BHW'];
close all
PHASE=[];
AMP=[];
load Conservative;
     %%%%%% get the fit parameters from the 2 sps run
     [L,M,N]=size(aaout);
     a1P=cell(3,1);
     for jk=1:L
     a1P{jk}=squeeze(aaout(jk,:,6:N));
     end
%%%%%%%%%% dc are the cleaned datasets %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  dc=cell(3,1);
  dc=Data;
  aaout3=[];
  kk=0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Main Loop %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for jk=1:3
    ii=1;
while ii<=length(I1P{jk})
kk=kk+1
iia(kk)=ii;
     gflag=G1P{jk}(ii); %%%% number of multi-glitches
     a2sps=a1P{jk}(ii,1:2*gflag); %%%% 2sps fit parameters
     AMP=[];PHASE=[];             %%%% ampl and phase from 2 sps fit
     for l=1:gflag; m=2*l;
         AMP(l)=a2sps(l);
         PHASE(l)=10*(a2sps(l+gflag));
     end  %%%%% used 2sps fits


     %%%% sort multi-glitches          
     [ph,ix]=sort(PHASE);
     PHASE=PHASE(ix);
     AMP=AMP(ix);
     %%% Set up glitch data for up to 4 glitches 
     ii0=ii; 
     N1=I1P{jk}(ii)*10-120;
     if      N1<1,N1=1; end
     if     gflag==1, N2=N1+500;ii=ii+1;ii;
     elseif gflag==2, N2=I1P{jk}(ii+1)*10+500-120;ii=ii+2;
     elseif gflag==3, N2=I1P{jk}(ii+2)*10+500-120;ii=ii+3; 
     elseif gflag==4, N2=I1P{jk}(ii+3)*10+500-120;ii=ii+4;
     end 
     %%% check limits
     if N2>length(Data{jk}),N2=length(Data{jk});end
     y=dc{jk}(N1:N2)';x=1:length(y);
     a=[]; %%%% paramters to be fit

     %%% check for wraparound phases overshoot
                for kj=1:4
                I1 = find(PHASE>length(y));
                if isempty(I1),continue, end
                PHASE(I1)=PHASE(I1)-length(y);
                end
     %%% check for wraparound phases undershoot
                for kj=1:4
                I1 = find(PHASE<0);
                if isempty(I1),continue, end
                PHASE(I1)=PHASE(I1)+length(y);
                end
    %%% sort phases            
                [PHASE,is]=sort(PHASE);
                AMP=AMP(is)
                
%%%%%%%%%%%%%%%%%%%%%%Fit and Compare 3 cases %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
PREP08
%%
ssq0=1e11;
     for ij=1:6
         mylsq,ssq;
         if ssq>ssq0
             a=a-da';fact=fact*10;
             ssq0=ssq;
         end
         ssq0=ssq;
      end
%      clf;plot(x,y,x,f);
% hold on;
% plot(x,y-f+y(1)+500)
%%%%%%%%%%%%%%%%%%%%%%%%%%% Skip these if Conservative =1 %%%%%%%%%%%%%%%%%
if Conservative == 0 
     outd.f1=f;
     outd.fflag1=fflag;
     outd.ssq1=ssq;
     outd.a1=a;
     outd.spiket1=spiket;
     outd.greent1=greent;
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
%%
 PREP03
 ssq0=1e11;
     for ij=1:6
         mylsq,ssq;
         ssqa(ij)=ssq;
         facta(ij)=fact;
         if ssq>ssq0
             a=a-da';fact=fact*2;
             ssq0=ssq;
         end
         ssq0=ssq;
     end 
% clf;plot(x,y,x,f);
% hold on;
% plot(x,y-f+y(1)+500)

     outd.f2=f;
     outd.fflag2=fflag;
     outd.ssq2=ssq;
     outd.a2=a;
     outd.spiket2=spiket;
     outd.greent2=greent;
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
%% 
PREP39
 ssq0=1e11;
     for ij=1:6
         mylsq,ssq;
         ssqa(ij)=ssq;
         facta(ij)=fact;
         if ssq>ssq0
             a=a-da';fact=fact*2;
             ssq0=ssq;
         end
         ssq0=ssq;
      end
% clf;plot(x,y,x,f);
% hold on;
% plot(x,y-f+y(1)+500)

     outd.f3=f;
     outd.fflag3=fflag;
     outd.ssq3=ssq;
     outd.a3=a;
     outd.spiket3=spiket;
     outd.greent3=greent;
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%  Which one is best fit %%%%%%%%%%%%%%%%%%%%%%%%%%%%
[mn,ix]=min([outd.ssq1,outd.ssq2,outd.ssq3]);
if ix==1,fflag=outd.fflag1;f=outd.f1;a=outd.a1;spiket=outd.spiket1;greent=outd.greent1;end
if ix==2,fflag=outd.fflag2;f=outd.f2;a=outd.a2;spiket=outd.spiket2;greent=outd.greent2;end
if ix==3,fflag=outd.fflag3;f=outd.f3;a=outd.a3;spiket=outd.spiket3;greent=outd.greent3;end

end; %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% here if Conservative ==1 %%%%%%%%%%%%%
ssq0=1e11;    
    fact=1;
    for ijj=1:6
         mylsq,ssq;
         if ssq>ssq0
             a=a-da';fact=fact*10;
             ssq0=ssq;
         end
%              clf;    
%              plot(x,y,x,f)
%              figure(1)
%              pause(1)
    end
    errors
    r=a./sdev';
%%%% eliminate low spikes fits %%%%%%%%%%%%%%%%%%%
load NLIMspike; %%%% threshold how many std to keep spike
a=testSpikes(a,x,y,f,greent,spiket,fflag,gflag,NLIMspike);
func
c=corrcoef(y,f);cc=c(1,2);
    figure(1) 
    clf
    plot(x,y,x,f)
    hold on
    plot(y-f+y(1)+500)
    title(['fflag=  ',num2str(fflag),'  cc =  ',num2str(cc,3), 'jk ', ...
        num2str(jk), ' ii ',num2str(ii)])
    pause(1)

%%
%%%%%%%%%%See every fit  plot small figures %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ix=mod(kk,12);
fg=floor(kk/12);
if ix==0, ix=12; fg=fg-1;end
figure(1000+fg);

subplot(4,3,ix)
plot(x,f,x,y)
hold on; plot(y-f+y(1)+500)
ch=cnames(jk,:)
title([ch,'   fflag=  ',num2str(fflag)]);
xlabel([datestr(datevec(times{jk}(N1)))], ...
'fontsize',10)
 xlim = [min(times{1}),max(times{1})];
 datetick('x','keeplimits')
 figure(1)
%%

%%%%% Replace glitches with residuals  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%           
D=y-f;
      x=1:length(y);
     slope=(y(end)-D(end)-y(1)+D(1))/(x(end)-x(1));
     line=y(1)-D(1)+slope*(x-x(1));
     dc{jk}(N1:N2)=D+line;
     aaout3{jk}(ii0,1:length(a)+2)=[a,N1,N2];
     aaout3{jk}(ii0,20)=fflag;
     
end  %%% ii loop  
end  %%% jk loop 
save aaout3 aaout3
save dc dc
%%%%%%%%% uncomment to plot results %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
PlotFinalNew

