%%% convolve green with a Gaussian to fit broadened data
function f=funcConvGaussSpikeThree(a,x,y,greent,spiket)
%%%%% fits green (response) spike, convolves with Gaussian and straight
%%%%% line to data y(x) 
%%%% Unknowns a; 
%%%% a(1)=amplitude green
%%%% a(2)=phase green
%%%% a(3)=Gaussian sd
%%%% a(4)=linear slope
%%%% a(5)=quadratic term
%%%% a(6)=offset
%%%% a(7)=amplitude spike
%%%% a(8)=phase spike
%%%% a(9)=amplitude second green
%%%% a(10)=phase second green
%%%% greenspike = spike(x)
%%%% green = impulse response function
%load y;
%'MADE IT HERE'
LX=length(x);
L0=round(LX/2);
T=exp(-((x-L0).^2/a(8)^2));
dt=1;
green_moved =a(1)*conv(rephase(greent,dt,a(2)-120),T,'same');
f1= green_moved;
line=a(3)+a(4)*(x/10)+a(5)*(x/10).^2;%  Curved line added
%%% fit green
f=f1+line;
%%%% Fit spike to y is  = delta
[ms,is]=max(spiket);
spike_moved=a(6)*rephase(spiket,1,a(7)-is);
f=f+spike_moved; 

% 
% plot(x,y,x,f)
% figure(1)
