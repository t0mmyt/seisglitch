%%%%% functions to remove spikes
    %%f=greenfitSlope(a,x);
    if fflag==0;  f=greenfitSlope(a,x,green,y,gflag,wminus);
elseif fflag==1;  f=funcFitGreen(a,x,y,greent);
elseif fflag==2;  f=funcConvGaussSpike(a,x,y,is,ix,pol);
elseif fflag==3;  f=funcConvGaussSpikeThree(a,x,y,greent,spiket);
elseif fflag==4;  f=greenfitSlopeLine(a,x,green,y,gflag,wminus);
elseif fflag==5;  f=SpikeSpikeGreenGreenLine(a,x,y,greent,spiket);
elseif fflag==6;  f=NSpikeGreenLine(a,x,y,green,spike,N);
elseif fflag==7;  f=funcNSpikeGreenLine(a,x,y,green,spike,N);
elseif fflag==8;  f=NSpikeFloatGreenLine(a,x,y,greent,spiket,gflag);
elseif fflag==9;  f=greenfitExpRampBox20SPS(a,x,green,y,gflag,wminus);
elseif fflag==10; f=funcFitStack(y,a);
elseif fflag==11; f=funcFitUPrecursor(y,a);
elseif fflag==12  f=funcFitSpikeGreen(a,x,y,greent,spiket)  
elseif fflag==13; f=NSpikeLockGreenLine(a,x,y,greent,spiket,N);
elseif fflag==14; f=funcFitGreenLine2SPS(a,x,y,green,wminus,gflag);
elseif fflag==15; f=funcReceiverPhases(a,inc)
elseif fflag==20; f=greenfitSlope20(a,green,y,gflag,sflag,wminus,dec);
elseif fflag==21; f=funcConvGauss2SPS(a,x,y);
elseif fflag==30; f=greenfitExp(a,x,green,y,gflag,wminus);
elseif fflag==31; f=greenfitExp20SPS(a,x,green,y,gflag,wminus);
elseif fflag==32; Receiver; %(a,Eastt,Northt,Downt);
elseif fflag==33; funcReceiverT
elseif fflag==34; f=greenfitExpAll20(a,x,green,y,gflag,wminus);
elseif fflag==35; f=greenfitExpAll(a,x,green,y,gflag,wminus);
elseif fflag==36; f=greenfitExpAll20B(a,x,green,y,gflag,wminus);
elseif fflag==37; f=greenStretch(a,x,y);
elseif fflag==38; funcFitSpike;
elseif fflag==39; f=greenfitExpCSpike20SPS(a,x,y,greent,spiket);
elseif fflag==40; f=greenfitExpCSpike10SPS(a,x,greent,spiket,y,eflag,sflag);
elseif fflag==41; funcChangeResponse;
elseif fflag==42; f=greenfitExp20SPSSpike(a,x,y,greent,spiket);
elseif fflag==100; f=convfunc(P,a);

end
%f=wiener(a,x);
    

