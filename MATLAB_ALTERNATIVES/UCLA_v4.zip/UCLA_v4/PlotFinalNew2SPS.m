%%% plots after cleaning
%function PlotFinalNew(data2,d2c,times2,I1P)
clf
jk=1
d2c=cell(3,1);
for jk=1:3,d2c{jk}=datacout(jk,:);end

jk=1
m1=mean(data2{jk});plot(times2{jk},data2{jk}+5500-m1,times2{jk}(I1P{jk}),data2{jk}(I1P{jk})+5500-m1,'r*', ...
'markersize',12,'markerfacecolor','g')
hold on
plot(times2{jk},d2c{jk}-m1+7000)
figure(1)
N1=length(I1P{1})
for i=1:N1,text(times2{jk}(I1P{1}(i))+300,data2{jk}(I1P{1}(i))+5500-m1,num2str(i),'fontsize',12);end


jk=2
m2=mean(data2{2});plot(times2{jk},data2{2}-m2-500,times2{jk}(I1P{jk}),data2{2}(I1P{2})-500-m2,'ro',...
    'markersize',6,'markerfacecolor','k')
plot(times2{jk},d2c{2}-m2+1000)
N2=length(I1P{2})
for i=1:N2,text(times2{jk}(I1P{2}(i))+300,data2{2}(I1P{2}(i))-500-m2,num2str(i),'fontsize',12);end

jk=3
m3=mean(data2{3});plot(times2{jk},data2{3}-4500-m3,times2{jk}(I1P{3}),data2{3}(I1P{3})-4500-m3,'k*')
plot(times2{jk},d2c{3}-m3-3000)
N3=length(I1P{3})
for i=1:N3,text(times2{jk}(I1P{3}(i))+300,data2{3}(I1P{3}(i))-4500-m3,num2str(i),'fontsize',12);end

figure(1)
out=pwd;
%%% MacProtitle(out(53:58))
%title(out(49:54))

xlabel([datestr(datevec(times2{1}(1))),' to  ', datestr(datevec(times2{1}(end)))], ...
 'fontsize',16)
 xlim = [min(times2{1}),max(times2{1})];
 datetick('x','keeplimits')
% clear xlim
 figure(1)  