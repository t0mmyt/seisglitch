function [indxa,ampspike,offspike]=FindPrecursors(data,spiket,gflag)
indxa=zeros(1,gflag);
ampspike=zeros(1,gflag);
offspike=zeros(1,gflag);

% figure(1)
% subplot(2,1,1)
[B,A]=butter(4,[.1,.5]);  %%%%%%%%%%%%% high frequencies show precursors
df=filtfilt(B,A,data);
ccv=conv(df,fliplr(spiket),'same');
kk=0;
for i=1:gflag
[~,ix1]=maxk(abs(ccv),1);
[~,ixs]=max(spiket);
m=ceil(length(spiket)/2);
mm=ceil(length(spiket)/2)-ixs;
indx=ix1-mm;
if indx-10>1 && indx+10<=length(data)
amp=std(df(indx-2:indx+2));
sd=std([df(indx-10:indx-3),df(indx+3:indx+10)]);
ratio=amp/sd;

%subplot(2,1,1)
% plot(data(indx-10:indx+10),'r*-');
% title(['Amp = ',num2str(amp),' std = ',num2str(sd),' ratio= ',num2str(ratio,3)])
% subplot(2,1,2)
% plot(ccv)
% hold on
% x=1:length(df);
% plot(x,df,x(indx),df(indx),'b*');
% plot(ix1,ccv(ix1),'r*')
% figure(1)

ix11=max([1,ix1-5]);ix22=min([ix1+5,length(data)]);
ccv(ix11:ix22)=0;
if ratio>1.4
    
    kk=kk+1;
    indxa(kk)=indx;
    ampspike(kk)=df(indx);
    offspike(kk)=ix1-m+0.001;
end
end
end
