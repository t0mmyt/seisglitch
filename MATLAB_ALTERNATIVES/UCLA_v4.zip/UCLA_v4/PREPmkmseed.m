filename1='XB.ELYSE.02.BHU.D';
filename2='XB.ELYSE.02.BHV.D';
filename3='XB.ELYSE.02.BHW.D';
mkmseed(filename1,dc{1}-Data{1},times{1},20);
mkmseed(filename2,dc{2}-Data{2},times{2},20);
mkmseed(filename3,dc{3}-Data{3},times{3},20);
!cat XB.* >temp.mseed
 out=pwd;
 filename=[out(53:58),'Corrections.mseed']
 copyfile('temp.mseed',filename)
  file=filename
  XseedDataFDS


filename1='XB.ELYSE.02.BHU.D';
filename2='XB.ELYSE.02.BHV.D';
filename3='XB.ELYSE.02.BHW.D';
mkmseed(filename1,dc{1},times{1},20);
mkmseed(filename2,dc{2},times{2},20);
mkmseed(filename3,dc{3},times{3},20);
!cat XB.* >temp.mseed
 out=pwd;
 filename=[out(53:58),'Corrected.mseed']
 copyfile('temp.mseed',filename)
  file=filename
  XseedDataFDS
%%  
filename1='XB.ELYSE.02.BHU.D';
filename2='XB.ELYSE.02.BHV.D';
filename3='XB.ELYSE.02.BHW.D';
mkmseed(filename1,Data{1},times{1},20);
mkmseed(filename2,Data{2},times{2},20);
mkmseed(filename3,Data{3},times{3},20);
!cat XB.* >temp.mseed
 out=pwd;
 filename=[out(53:58),'RawData.mseed']
 copyfile('temp.mseed',filename)
  file=filename
  XseedDataFDS