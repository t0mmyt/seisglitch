%%% plots after cleaning
%function PlotFinalNew(Data,dc,times,I1P)
clf
jk=1
m1=mean(Data{jk});plot(times{jk},Data{jk}+5500-m1,times{jk}(I1P{jk}*10),Data{jk}(10*I1P{jk})+5500-m1,'r*', ...
'markersize',12,'markerfacecolor','g')
hold on
plot(times{jk},dc{jk}-m1+7000)
figure(1)
N1=length(I1P{1})
for i=1:N1,text(times{jk}(I1P{1}(i))*10+300,Data{jk}(10*I1P{1}(i))+5500-m1,num2str(i),'fontsize',12);end


jk=2
m2=mean(Data{2});plot(times{jk},Data{2}-m2-500,times{jk}(10*I1P{jk}),Data{2}(10*I1P{2})-500-m2,'ro',...
    'markersize',6,'markerfacecolor','k')
plot(times{jk},dc{2}-m2+1000)
N2=length(I1P{2})
for i=1:N2,text(times{jk}(I1P{2}(i))*10+300,Data{2}(10*I1P{2}(i))-500-m2,num2str(i),'fontsize',12);end

jk=3
m3=mean(Data{3});plot(times{jk},Data{3}-4500-m3,times{jk}(10*I1P{3}),Data{3}(10*I1P{3})-4500-m3,'k*')
plot(times{jk},dc{3}-m3-3000)
N3=length(I1P{3})
for i=1:N3,text(times{jk}(I1P{3}(i))*10+300,Data{3}(10*I1P{3}(i))-4500-m3,num2str(i),'fontsize',12);end

figure(1)
out=pwd;
%%% MacProtitle(out(53:58))
%title(out(49:54))

xlabel([datestr(datevec(times{1}(1))),' to  ', datestr(datevec(times{1}(end)))], ...
 'fontsize',16)
 xlim = [min(times{1}),max(times{1})];
 datetick('x','keeplimits')
% clear xlim
 figure(1)  