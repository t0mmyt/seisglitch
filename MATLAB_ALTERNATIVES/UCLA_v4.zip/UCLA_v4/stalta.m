%%%% sta lta for  Mars Insight data
load green2sps;
green=green2sps;
green  = green-green(1); %%%% offset.
%%%%%%% band pass
 greenf=filtfilt(B,A,green); %%%%%%% 
 green=greenf;
 [mx,ix]=max(green);
 yg=green(ix-30:ix+50)/mx;    %%%% impulse response                              
 yg=yg/max(yg);                %%%% normalize                            
%%
greent=yg;
close all
x=1:length(yg);
[mx,ix]=max(yg);L=length(yg);
xp=x(ix+1:L);
xn=x(1:ix);
 x=[xn,xp];            %%%% each 0.5 sec axis                                     
 %yt = [exp(-(xn -ix+1).^2/12),exp(-(xp -ix+1).^2/80)];
 yt = exp(-(x -ix+1).^2/12);
 plot(x,yg,x,yt)
 pause(1)
 filt=(fftshift(ifft(fft(yt)./(fft(yg)+0.01)))); %%%% invert convolution
 hold on
 plot(x,conv(yg,filt,'same'),'r',x,yt,'k*')  %%%% check filter
 title(' Test of inverse filter to turn Green to Gaussian')
 pause(2)
%%
dataf=filtfilt(B,A,data);
datacon =conv(dataf, filt,'same');  %%%% string of gaussians
sta =1/3*conv(abs(datacon),ones(1,3),'same');
%%%%%%%%%%%% removes largest glitches in filtered data %%%%%%%%%%%%%%%%%%%%
QuickClean
%%%%%%%%%%%%%%%%%%%%%%% Transforms glitches to Gaussians %%%%%%%%%%%%%%%%%%
dataconc=conv(datacf,filt,'same');  %%%% convolve cleaned data
%%%%%%%%%%% Set up long term average %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
leftta = conv(abs([zeros(1,100),dataconc(1:end-100)]),ones(1,200)/200,'same');
rightta =conv(abs([dataconc(1:end-100),zeros(1,100)]),ones(1,200)/200,'same');
lta=min([leftta;rightta]);
lta(1:200)=lta(201:400);               %%%%% avoid end effects
lta(end-200:end)=lta(end-400:end-200); %%%%% avoid end effects
J1=find(lta==0); lta(J1)=median(lta);  %%%%% avoid divide by zero
dataratio=sta./lta;                    %%%%% short over long term average             
findmaxs                               %%%%% get maxima peak indexes

