%%%%%% Get green from Philippes's program and fit to multiple glitches
%%%%%% 
function f=greenfitExpCSpike20SPS(a,x,y,greent,spiket);
green=greent;
E=exp(-(0:5000)/abs(a(5)));
[mg,ig]=max(greent);
template1=conv(E/max(E),green);
template1=template1/max(template1);
% %%%%%%%%%%%% line up template and green
 [mg,ixg]=max(diff(diff(greent)));
 [mt,ixt]=max(diff(diff(template1)));
 [ms,is]=max(spiket);
 m1=ixt-ixg+1;m2=m1+length(y)-1;
 template=template1(m1:m2);
                                                     f2=template;

x=1:length(y);
dt=1;
                                                    f1=greent/max(greent);
%%%%%%% fit spike 
                                                    f3=spiket;

f=a(1)*rephase(f1,dt,a(3)-ig)+a(2)*rephase(f2,dt,a(4))+a(6)+a(7)*x+a(8)*rephase(f3,1,a(9)-is);
%   figure(1)
%   plot(x,f,x,y)
