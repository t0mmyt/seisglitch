
%	- to extrvact the station component n from av multiplexed file:
% file='fdsnws_msds.mseed'
 		[X,I] = rdmseed(file,'plot');
         out1=size(char(I.ChannelFullName))
         out=char(I.ChannelFullName)

        %break
for n=1:out1(1)
% subplot(8,1,n)
% figure(n+1)format long
 		k = I(n).XBlockIndex;
% 		plot(cat(1,X(k).t),cat(1,X(k).d))
% 		datetick('x')
		title(I(n).ChannelFullName)
        if out(n,10:15)=='03:BDO',d1=cat(1,X(k).d);t1=cat(1,X(k).t);end

        if out(n,10:15)=='02:MDO',d1=cat(1,X(k).d);t1=cat(1,X(k).t);end
        if out(n,10:15)=='02:BHU',d2=cat(1,X(k).d);t2=cat(1,X(k).t);end
        if out(n,10:15)=='02:BHV',d3=cat(1,X(k).d);t3=cat(1,X(k).t);end
        if out(n,10:15)=='02:BHW',d4=cat(1,X(k).d);t4=cat(1,X(k).t);end
        if out(n,10:15)=='65:EHU',d5=cat(1,X(k).d);t5=cat(1,X(k).t);end
        if out(n,10:15)=='65:EHV',d6=cat(1,X(k).d);t6=cat(1,X(k).t);end
        if out(n,10:15)=='65:EHW',d7=cat(1,X(k).d);t7=cat(1,X(k).t);end
        if out(n,10:15)=='00:HHV',d6=cat(1,X(k).d);t6=cat(1,X(k).t);end
        if out(n,10:15)=='00:HHV',d6=cat(1,X(k).d);t6=cat(1,X(k).t);end
        if out(n,10:15)=='03:VKI',d9=cat(1,X(k).d);t9=cat(1,X(k).t);end
        if out(n,10:15)=='12:VKO',d12=cat(1,X(k).d);t12=cat(1,X(k).t);end
        if out(n,10:15)=='23:VKO',d23=cat(1,X(k).d);t23=cat(1,X(k).t);end
        if out(n,10:15)=='20:VKO',d20=cat(1,X(k).d);t20=cat(1,X(k).t);end
        if out(n,10:15)=='22:VKO',d22=cat(1,X(k).d);t22=cat(1,X(k).t);end
        if out(n,10:15)=='23:VKO',d23=cat(1,X(k).d);t23=cat(1,X(k).t);end
        if out(n,10:15)=='30:VKO',d30=cat(1,X(k).d);t30=cat(1,X(k).t);end
        if out(n,10:15)=='33:VKO',d33=cat(1,X(k).d);t33=cat(1,X(k).t);end

%         if out(n,13:15)=='MDO',d5=cat(1,X(k).d);t5=cat(1,X(k).t),end
%         if out(n,13:15)=='MDO',d6=cat(1,X(k).d);t6=cat(1,X(k).t),end
%         if out(n,13:15)=='MDO',d7=cat(1,X(k).d);t7=cat(1,X(k).t),end
%         if out(n,13:15)=='MDO',d8=cat(1,X(k).d);t8=cat(1,X(k).t),end





end

% figure(2)
% clf
% plot((t3-t3(1))*24*60,d3,(t2-t2(1))*24*60,d2+5e5,'r',(t1-t1(1))*24*60,d1+10e5,'k')
